#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <cmath>
using namespace std;
const float pi=3.142;

 class Shapes{
 public:
   virtual float getArea()=0;
   virtual float getParameter()=0;
 };
 class Circle:public Shapes{
 private:
   float radius;
 public:
   Circle(float r){
     radius=r;
   }
   float getArea(){
     return pi*radius*radius;
   }
   float getParameter(){
     return 2*pi*radius;
   }
 };
 class Rectangle:public Shapes{
 private:
   float width,height;
 public:
   Rectangle(float w,float h){
     width=w;
     height=h;
   }
   float getArea(){
     return width*height;
   }
   float getParameter(){
     return 2*(width+height);
 }
};
 class Triangle:public Shapes{
 private:
   float base,height1;

 public:
   Triangle(float b,float h){
     base=b;
     height1=h;
   }
   float getArea(){
     return 0.5*base*height1;
   }
   float getParameter(){
     return base+height1+sqrt(pow(base,2)+pow(height1,2));
   }
 };
int main()
  {
  string line;
  ifstream in("lab12.txt");
  ofstream out("RecordShapes.csv");
  out<<"ShapeType"<<","<<"Length1"<<","<<"Length2"<<","<<"Perimeter"<<","<<"Area"<<endl;
  int length;
  int count=0;
  char shapenme;
  string f,s;//two number for value storage
  double fi,se;
  while(getline(in,line)){
    length=line.length();
    shapenme=line[0];//we are storing the 1st value of the string to a variable
    for(float i=2;i<length;i++){//we are starting from 2 as 0,1 are 1st char and ","
        if(line[i]==','){
          count=1;//to differentiate btw 2nd num available or not
        }
        else if(count==0){
          f+=line[i];//saving first number
        }
        else if(count==1){
          s+=line[i];//saving 2nd number
        }
        }

        cout<<"\n"<<shapenme<<endl;
        fi= stod (f.substr());//changing string to double
        cout<<fi<<endl;
        if(shapenme=='c'){
        if(count==0){
            se=1;//Default=1
          }
          else
            se=stod(s.substr());
            cout<<se<<endl;
          Circle c1(fi);
          cout<<c1.getArea()<<endl;
          cout<<c1.getParameter()<<endl;
          out<<"Circle"<<","<<fi<<","<<se<<","<<c1.getParameter()<<","<<c1.getArea()<<endl;
                }
        if(shapenme=='r'){
          if(count==0){
            se=1;//Default=1
          }
          else
            se=stod(s.substr());
            cout<<se<<endl;
            Rectangle r1(fi,se);
            cout<<r1.getArea()<<endl;
            cout<<r1.getParameter()<<endl;
            out<<"Rectangle"<<","<<fi<<","<<se<<","<<r1.getParameter()<<","<<r1.getArea()<<endl;
        }
        if(shapenme=='t'){
          if(count==0){
            se=1;//Default=1
          }
          else
            se=stod(s.substr());
            cout<<se<<endl;
            Triangle t1(fi,se);
            cout<<t1.getArea()<<endl;
            cout<<t1.getParameter()<<endl;
            out<<"Triangle"<<","<<fi<<","<<se<<","<<t1.getParameter()<<","<<t1.getArea()<<endl;
        }
      count=0;
      f.clear();
      s.clear();
    }

return 0;
}
