#include<iostream>
#include<fstream>
#include<string>
#include<cmath>
#include<cstdlib>
#include <bits/stdc++.h>

using namespace std;

 class Shapes{
 protected:
   const float pi=3.142;
 public:
   Shapes();
   virtual int getArea()=0;
   virtual int getParameter()=0;
 };
 class Circle:public Shapes{
 private:
   int radius;
 public:
   Circle(int r){
     radius=r;
   }
   int getArea(int r){
     return pi*r*r;
   }
   int getParameter(int r){
     return 2*pi*r;
   }
 };
 class Rectangle:public Shapes{
 private:
   int width,height;
 public:
   Rectangle(int w,int h){
     width=w;
     height=h;
   }
   int getArea(int w,int h){
     return w*h;
   }
   int getParameter(int w,int h){
     return 2*(w+h);
 };
 class Triangle:public Shapes{
 private:
   int base,height;

 public:
   Triangle(int b,int h){
     base=b;
     height=h;
   }
   int getArea(int b,int h){
     return (1/2)*b*h;
   }
   int getParameter(int b,int h){
     int c;
     c=sqrt(pow(b,2)+pow(h,2));
     return c+b+h;
   }
 };

int main () {
  string line;
  ifstream file ("lab12.txt");
  if(file.is_open())
  {
    while(getline(file,line) )
    {
      cout<<line<< endl;
    }
    file.close();
  }

  else {
    cout<<"Unable to open file";}
    string line = "GeeksForGeeks is a must try";
    vector <string> tokens;
    stringstream check1(line);
    string intermediate;
    while(getline(check1, intermediate, ' '))
    {
        tokens.push_back(intermediate);
    }
    for(int i = 0; i < tokens.size(); i++)
        cout << tokens[i] << '\n';
}
  return 0;
}
