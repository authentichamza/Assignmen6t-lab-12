// #include <iostream>
// #include <fstream>
// #include <string>
// using namespace std;
//
// int main () {
//   string line;
//   ifstream myfile ("example.txt");
//   if (myfile.is_open())
//   {
//     while ( getline (myfile,line) )
//     {
//       cout << line << '\n';
//     }
//     myfile.close();
//   }
//
//   else cout << "Unable to open file";
//
//   return 0;
#include<iostream>
#include<fstream>
#include<string>
#include <bits/stdc++.h>
using namespace std;
int main(){
  string line;
  ifstream myfile("lab12.txt");
    vector <string> tokens;
    stringstream check1(line);
    string intermediate;
    while(getline(check1, intermediate, ' '))
    {
        tokens.push_back(intermediate);
    }
    for(int i = 0; i < tokens.size(); i++)
        cout << tokens[i] << '\n';}
